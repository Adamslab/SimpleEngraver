You have the option to use 21.5mm OD roller wheels or 24mm OD V-Slot wheels.

There are two versions available for 24mm OD V-Slot wheels. 
One is for T-Slot extrusions, the other is sized to fit V-Slot extrusions.
